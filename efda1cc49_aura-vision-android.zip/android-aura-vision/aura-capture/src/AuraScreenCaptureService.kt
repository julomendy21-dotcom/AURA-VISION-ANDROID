package app.aura.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File

/**
 * Service de premier plan qui porte la session MediaProjection.
 *
 * Ordre imposé par Android 14 : le service passe au premier plan AVANT
 * getMediaProjection. Il continue d'enregistrer quand l'utilisateur ouvre une
 * autre application, et s'arrête uniquement sur action de l'utilisateur
 * (notification, page AURA VISION) ou retrait de l'autorisation système.
 */
class AuraScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var activeFps = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin(intent)
            ACTION_STOP -> stopCapture("user")
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun begin(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val resultData = projectionResult(intent)
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return
        }

        createChannel()
        val foregroundType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), foregroundType)

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val session = try {
            manager.getMediaProjection(resultCode, resultData)
        } catch (error: Exception) {
            null
        }
        if (session == null) {
            release()
            stopSelf()
            return
        }
        projection = session
        session.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // L'utilisateur a retiré l'autorisation depuis Android.
                stopCapture("system")
            }
        }, Handler(Looper.getMainLooper()))

        val metrics = displayMetrics()
        val width = metrics.widthPixels - (metrics.widthPixels % 2)
        val height = metrics.heightPixels - (metrics.heightPixels % 2)
        val directory = File(getExternalFilesDir(null), "AuraCapture").apply { mkdirs() }
        val target = File(directory, "aura-screen-${System.currentTimeMillis()}.mp4")

        val prepared = buildRecorder(target, width, height)
        if (prepared == null) {
            release()
            stopSelf()
            broadcast(ActionOutcome.FAILED, null, null, "encoder_unavailable")
            return
        }
        recorder = prepared.first
        activeFps = prepared.second
        outputFile = target

        virtualDisplay = session.createVirtualDisplay(
            "AuraCapture",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            prepared.first.surface,
            null,
            null
        )

        val started = try {
            prepared.first.start()
            true
        } catch (error: Exception) {
            false
        }
        if (!started) {
            target.delete()
            release()
            stopSelf()
            broadcast(ActionOutcome.FAILED, null, null, "start_failed")
            return
        }

        AuraCaptureState.isRecording = true
        AuraCaptureState.startedAtMs = System.currentTimeMillis()
    }

    /**
     * Cible 60 fps, repli réel à 30 fps si l'encodeur du téléphone refuse.
     * La cadence effectivement obtenue est mesurée après l'arrêt.
     */
    private fun buildRecorder(file: File, width: Int, height: Int): Pair<MediaRecorder, Int>? {
        for (fps in intArrayOf(TARGET_FPS_HIGH, TARGET_FPS_FALLBACK)) {
            val candidate = MediaRecorder()
            try {
                candidate.setVideoSource(MediaRecorder.VideoSource.SURFACE)
                candidate.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                candidate.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                candidate.setVideoSize(width, height)
                candidate.setVideoFrameRate(fps)
                candidate.setVideoEncodingBitRate(if (fps >= TARGET_FPS_HIGH) BIT_RATE_HIGH else BIT_RATE_FALLBACK)
                candidate.setOutputFile(file.absolutePath)
                candidate.prepare()
                return candidate to fps
            } catch (error: Exception) {
                runCatching {
                    candidate.reset()
                    candidate.release()
                }
            }
        }
        return null
    }

    /** Arrêt demandé par la notification ou par la page web. */
    private fun stopCapture(reason: String) {
        val file = outputFile
        val wasRecording = AuraCaptureState.isRecording
        var clean = true
        try {
            recorder?.stop()
        } catch (error: RuntimeException) {
            // Séquence trop courte : le conteneur MP4 est incomplet.
            clean = false
            file?.delete()
        }

        release()
        AuraCaptureState.isRecording = false

        if (!wasRecording) {
            stopSelf()
            return
        }

        if (!clean || file == null || !file.exists() || file.length() == 0L) {
            broadcast(ActionOutcome.FAILED, null, null, "too_short")
            stopSelf()
            return
        }

        val info = AuraMediaProbe.inspect(file.absolutePath).apply {
            put("targetFps", activeFps)
            put("stoppedBy", reason)
            put("startedAtMs", AuraCaptureState.startedAtMs)
            put("endedAtMs", System.currentTimeMillis())
        }
        AuraCaptureState.saveLastCapture(this, file.absolutePath, info)
        if (info.optBoolean("readable")) copyToGallery(file)
        broadcast(if (info.optBoolean("readable")) ActionOutcome.STOPPED else ActionOutcome.FAILED, file.absolutePath, info, null)
        stopSelf()
    }

    private fun release() {
        runCatching {
            recorder?.reset()
            recorder?.release()
        }
        recorder = null
        virtualDisplay?.release()
        virtualDisplay = null
        projection?.stop()
        projection = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    }

    /** Copie publique dans Movies/AuraVision : la vidéo reste retrouvable dans la galerie. */
    private fun copyToGallery(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AuraVision")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        try {
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }
            val uri = contentResolver.insert(collection, values) ?: return
            contentResolver.openOutputStream(uri)?.use { sink ->
                file.inputStream().use { source -> source.copyTo(sink, 64 * 1024) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
            }
        } catch (error: Exception) {
            // Copie galerie non bloquante : le fichier privé reste la référence.
        }
    }

    private fun broadcast(outcome: ActionOutcome, path: String?, info: JSONObject?, reason: String?) {
        val intent = Intent(ACTION_FINISHED).setPackage(packageName)
        intent.putExtra(EXTRA_OUTCOME, outcome.name)
        if (!path.isNullOrEmpty()) intent.putExtra(EXTRA_FILE_PATH, path)
        if (info != null) intent.putExtra(EXTRA_INFO, info.toString())
        if (!reason.isNullOrEmpty()) intent.putExtra(EXTRA_REASON, reason)
        sendBroadcast(intent)
    }

    private fun projectionResult(intent: Intent): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
    }

    private fun displayMetrics(): DisplayMetrics {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = manager.currentWindowMetrics.bounds
            DisplayMetrics().also {
                it.widthPixels = bounds.width()
                it.heightPixels = bounds.height()
                it.densityDpi = resources.displayMetrics.densityDpi
            }
        } else {
            DisplayMetrics().also {
                @Suppress("DEPRECATION")
                manager.defaultDisplay.getRealMetrics(it)
            }
        }
    }

    private fun createChannel() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL_ID, "AURA Capture", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Capture d'écran AURA VISION en cours"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, AuraCaptureActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, AuraScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AURA VISION enregistre l'écran")
            .setContentText("Vous pouvez utiliser une autre application. Touchez Arrêter pour terminer.")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setUsesChronometer(true)
            .setWhen(System.currentTimeMillis())
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp)
            .addAction(0, "Arrêter", stopIntent)
            .build()
    }

    override fun onDestroy() {
        release()
        AuraCaptureState.isRecording = false
        super.onDestroy()
    }

    enum class ActionOutcome { STOPPED, FAILED }

    companion object {
        const val ACTION_START = "app.aura.capture.START"
        const val ACTION_STOP = "app.aura.capture.STOP"
        const val ACTION_FINISHED = "app.aura.capture.FINISHED"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_FILE_PATH = "filePath"
        const val EXTRA_INFO = "info"
        const val EXTRA_OUTCOME = "outcome"
        const val EXTRA_REASON = "reason"

        private const val CHANNEL_ID = "aura_capture"
        private const val NOTIFICATION_ID = 42
        private const val TARGET_FPS_HIGH = 60
        private const val TARGET_FPS_FALLBACK = 30
        private const val BIT_RATE_HIGH = 16_000_000
        private const val BIT_RATE_FALLBACK = 8_000_000

        /** Demande l'arrêt sans redémarrer le service s'il tourne déjà. */
        fun stop(context: Context) {
            val intent = Intent(context, AuraScreenCaptureService::class.java).setAction(ACTION_STOP)
            try {
                context.startService(intent)
            } catch (error: Exception) {
                ContextCompat.startForegroundService(context, intent)
            }
        }
    }
}