package app.aura.capture

import android.content.Context
import java.io.BufferedOutputStream
import java.io.File
import java.io.InputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/**
 * Pont local très restreint : sert UNIQUEMENT le dernier MP4 enregistré,
 * sur 127.0.0.1, à un port aléatoire et sous un chemin protégé par un jeton
 * aléatoire. Rien n'est exposé sur le réseau, aucun autre fichier n'est lisible.
 *
 * Il permet à la page AURA VISION (WebView) de récupérer automatiquement la
 * vidéo après l'arrêt de la capture, sans redemander de sélection de fichier.
 */
object AuraCaptureServer {

    @Volatile
    private var serverSocket: ServerSocket? = null

    @Volatile
    var port: Int = 0
        private set

    private var appContext: Context? = null

    fun start(context: Context) {
        if (serverSocket != null) return
        appContext = context.applicationContext
        val server = try {
            ServerSocket(0, 4, InetAddress.getByName("127.0.0.1"))
        } catch (error: Exception) {
            return
        }
        serverSocket = server
        port = server.localPort
        thread(name = "aura-capture-bridge", isDaemon = true) {
            while (!server.isClosed) {
                val client = try {
                    server.accept()
                } catch (error: Exception) {
                    break
                }
                thread(isDaemon = true) { serve(client) }
            }
        }
    }

    fun stop() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        port = 0
    }

    /** URL du dernier fichier, ou chaîne vide s'il n'y a rien à servir. */
    fun latestUrl(context: Context): String {
        val file = AuraCaptureState.lastFilePath(context)?.let { File(it) } ?: return ""
        if (!file.exists() || file.length() == 0L) return ""
        if (port == 0) start(context)
        if (port == 0) return ""
        return "http://127.0.0.1:$port/${AuraCaptureState.bridgeToken(context)}/latest.mp4"
    }

    private fun serve(client: Socket) {
        try {
            val input = client.getInputStream()
            val requestLine = readLine(input) ?: return
            val out = BufferedOutputStream(client.getOutputStream())
            val parts = requestLine.split(" ")
            val method = parts.getOrNull(0) ?: ""
            val path = parts.getOrNull(1) ?: ""

            val context = appContext
            if (context == null) {
                writeStatus(out, "503 Service Unavailable")
                return
            }
            val expected = "/${AuraCaptureState.bridgeToken(context)}/latest.mp4"
            if (path != expected || (method != "GET" && method != "HEAD")) {
                writeStatus(out, "404 Not Found")
                return
            }
            val file = AuraCaptureState.lastFilePath(context)?.let { File(it) }
            if (file == null || !file.exists() || file.length() == 0L) {
                writeStatus(out, "404 Not Found")
                return
            }

            val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: video/mp4\r\n" +
                "Content-Length: ${file.length()}\r\n" +
                "Accept-Ranges: none\r\n" +
                "Cache-Control: no-store\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n\r\n"
            out.write(header.toByteArray())
            if (method == "GET") {
                file.inputStream().use { it.copyTo(out, 64 * 1024) }
            }
            out.flush()
        } catch (error: Exception) {
            // connexion interrompue par la page : rien à signaler
        } finally {
            runCatching { client.close() }
        }
    }

    private fun readLine(input: InputStream): String? {
        val builder = StringBuilder()
        var previous = -1
        while (true) {
            val current = input.read()
            if (current == -1) return if (builder.isEmpty()) null else builder.toString()
            if (current == '\n'.code && previous == '\r'.code) {
                return builder.dropLast(1).toString()
            }
            builder.append(current.toChar())
            previous = current
        }
    }

    private fun writeStatus(out: BufferedOutputStream, status: String) {
        val body = status.toByteArray()
        out.write("HTTP/1.1 $status\r\nContent-Length: ${body.size}\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(body)
        out.flush()
    }
}