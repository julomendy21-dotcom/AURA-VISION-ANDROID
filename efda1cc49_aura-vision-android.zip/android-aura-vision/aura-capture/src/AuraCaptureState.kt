package app.aura.capture

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.util.UUID

/**
 * État partagé entre l'activité (WebView), le service de capture et le pont JS.
 * Volatile : le service écrit depuis un autre thread que la page.
 */
object AuraCaptureState {

    @Volatile
    var isRecording: Boolean = false

    @Volatile
    var startedAtMs: Long = 0L

    private const val PREFS = "aura_capture"
    private const val KEY_LAST_FILE = "last_file"
    private const val KEY_LAST_INFO = "last_info"
    private const val KEY_TOKEN = "bridge_token"

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Enregistre le dernier fichier produit et ses mesures réelles. */
    fun saveLastCapture(context: Context, path: String, info: JSONObject) {
        prefs(context).edit()
            .putString(KEY_LAST_FILE, path)
            .putString(KEY_LAST_INFO, info.toString())
            .apply()
    }

    fun lastFilePath(context: Context): String? = prefs(context).getString(KEY_LAST_FILE, null)

    fun lastInfo(context: Context): String? = prefs(context).getString(KEY_LAST_INFO, null)

    /** Jeton aléatoire du pont local : la page doit le connaître pour lire le fichier. */
    fun bridgeToken(context: Context): String {
        val stored = prefs(context).getString(KEY_TOKEN, null)
        if (stored != null && stored.length >= 16) return stored
        val created = UUID.randomUUID().toString().replace("-", "")
        prefs(context).edit().putString(KEY_TOKEN, created).apply()
        return created
    }
}