package app.aura.capture

import android.webkit.JavascriptInterface

/**
 * Pont exposé à la page web sous window.AuraCapture.
 * Présent uniquement dans l'application Android : sur le web seul, la page
 * continue d'utiliser getDisplayMedia.
 */
class AuraCaptureBridge(private val activity: AuraCaptureActivity) {

    @JavascriptInterface
    fun isNativeCaptureAvailable(): Boolean = true

    @JavascriptInterface
    fun isRecording(): Boolean = AuraCaptureState.isRecording

    @JavascriptInterface
    fun requestPermissions() {
        activity.runOnUiThread { activity.ensureNotificationPermission() }
    }

    @JavascriptInterface
    fun startCapture() {
        activity.runOnUiThread { activity.requestScreenCapture() }
    }

    @JavascriptInterface
    fun stopCapture() {
        activity.runOnUiThread { activity.stopCaptureService() }
    }

    /** URL locale du dernier MP4, ou "" s'il n'y a rien à récupérer. */
    @JavascriptInterface
    fun latestCaptureUrl(): String = AuraCaptureServer.latestUrl(activity)

    /** Mesures réelles du dernier fichier (JSON), ou "{}". */
    @JavascriptInterface
    fun latestCaptureInfo(): String = AuraCaptureState.lastInfo(activity) ?: "{}"

    @JavascriptInterface
    fun version(): String = "1.0.0"
}