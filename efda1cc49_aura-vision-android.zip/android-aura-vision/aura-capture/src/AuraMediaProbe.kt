package app.aura.capture

import android.media.MediaMetadataRetriever
import android.os.Build
import org.json.JSONObject
import java.io.File

/**
 * Mesures réelles du fichier enregistré : durée, résolution, images, cadence
 * moyenne obtenue et intégrité. Aucune valeur n'est estimée : si Android ne
 * fournit pas la donnée, la clé est absente.
 */
object AuraMediaProbe {

    fun inspect(path: String): JSONObject {
        val info = JSONObject()
        val file = File(path)
        info.put("path", path)
        info.put("exists", file.exists())
        info.put("sizeBytes", if (file.exists()) file.length() else 0L)

        var durationMs = 0L
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(path)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 0
            info.put("durationMs", durationMs)
            info.put("width", width)
            info.put("height", height)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val frames = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)
                    ?.toLongOrNull() ?: -1L
                if (frames > 0) {
                    info.put("frameCount", frames)
                    if (durationMs > 0) {
                        val fps = frames * 1000.0 / durationMs.toDouble()
                        info.put("fps", Math.round(fps * 100.0) / 100.0)
                    }
                }
            }
        } catch (error: Exception) {
            info.put("error", error.javaClass.simpleName)
        } finally {
            runCatching { retriever.release() }
        }

        val width = info.optInt("width", 0)
        info.put("readable", durationMs > 0 && width > 0 && info.optLong("sizeBytes", 0L) > 0)
        return info
    }
}