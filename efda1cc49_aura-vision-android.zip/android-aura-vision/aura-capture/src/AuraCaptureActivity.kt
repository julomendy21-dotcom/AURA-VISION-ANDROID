package app.aura.capture

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.FileChooserParams
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * Activité hôte d'AURA VISION.
 *
 * L'interface reste celle de l'application web (chargée dans une WebView) :
 * aucun écran n'est réécrit. Les fonctions natives (MediaProjection, service
 * de premier plan, galerie) sont exposées à la page par le pont AuraCapture.
 *
 * Aucune capture n'est possible sans l'autorisation Android validée par
 * l'utilisateur à chaque session.
 */
class AuraCaptureActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var webPermissionRequest: PermissionRequest? = null
    private var receiverRegistered = false

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                startForegroundCapture(result.resultCode, data)
            } else {
                notifyWeb("denied", null)
            }
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* la capture reste possible sans */ }

    private val runtimePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val request = webPermissionRequest
            webPermissionRequest = null
            if (request == null) return@registerForActivityResult
            if (granted) request.grant(request.resources) else request.deny()
        }

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val callback = fileCallback
            fileCallback = null
            if (callback == null) return@registerForActivityResult
            val data = result.data
            val uris: Array<Uri>? = when {
                result.resultCode != Activity.RESULT_OK -> null
                data?.clipData != null -> {
                    val clip = data.clipData!!
                    Array(clip.itemCount) { clip.getItemAt(it).uri }
                }
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
            callback.onReceiveValue(uris)
        }

    private val finishedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != AuraScreenCaptureService.ACTION_FINISHED) return
            val outcome = intent.getStringExtra(AuraScreenCaptureService.EXTRA_OUTCOME)
            val info = intent.getStringExtra(AuraScreenCaptureService.EXTRA_INFO)
            val path = intent.getStringExtra(AuraScreenCaptureService.EXTRA_FILE_PATH)
            when (outcome) {
                AuraScreenCaptureService.ActionOutcome.STOPPED.name -> notifyWeb("stopped", info)
                AuraScreenCaptureService.ActionOutcome.FAILED.name -> notifyWeb(
                    "error",
                    JSONObject().apply {
                        put("state", "error")
                        put("reason", intent.getStringExtra(AuraScreenCaptureService.EXTRA_REASON) ?: "unknown")
                    }.toString()
                )
                else -> notifyWeb(if (path.isNullOrEmpty()) "error" else "stopped", info)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        configureWebView()
        AuraCaptureServer.start(this)
        registerFinishedReceiver()
        askNotificationPermission()
        webView.loadUrl(getString(R.string.aura_app_url))
    }

    @Suppress("SetJavaScriptEnabled", "DEPRECATION")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            // Nécessaire pour lire le MP4 servi par la boucle locale (http://127.0.0.1).
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = "$userAgentString AuraVisionAndroid/1.0.0"
        }

        webView.addJavascriptInterface(AuraCaptureBridge(this), "AuraCapture")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                val host = url.host ?: return false
                if (host == "127.0.0.1" || host == "localhost" || host.endsWith("base44.app")) return false
                return openExternally(url)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val intent = params?.createIntent()
                        ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "video/*" }
                    fileChooser.launch(intent)
                    true
                } catch (error: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                if (!request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                    request.deny()
                    return
                }
                if (ContextCompat.checkSelfPermission(
                        this@AuraCaptureActivity,
                        Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    request.grant(request.resources)
                } else {
                    webPermissionRequest = request
                    runtimePermission.launch(Manifest.permission.CAMERA)
                }
            }
        }
    }

    private fun openExternally(url: Uri): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, url))
            true
        } catch (error: Exception) {
            false
        }
    }

    /** Appelée par le pont JavaScript : demande l'autorisation Android. */
    fun requestScreenCapture() {
        if (AuraCaptureState.isRecording) {
            notifyWeb("recording", null)
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    fun stopCaptureService() {
        AuraScreenCaptureService.stop(this)
    }

    fun ensureNotificationPermission() = askNotificationPermission()

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        ) return
        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun startForegroundCapture(resultCode: Int, data: Intent) {
        val intent = Intent(this, AuraScreenCaptureService::class.java).apply {
            action = AuraScreenCaptureService.ACTION_START
            putExtra(AuraScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(AuraScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        ContextCompat.startForegroundService(this, intent)
        notifyWeb("recording", null)
    }

    /** Prévient la page de l'état réel de la capture. */
    fun notifyWeb(state: String, info: String?) {
        val detail = JSONObject().apply {
            put("state", state)
            if (!info.isNullOrEmpty()) {
                put("info", runCatching { JSONObject(info) }.getOrElse { JSONObject() })
            }
        }
        val script = "window.dispatchEvent(new CustomEvent('aura-capture', { detail: $detail }));"
        webView.post { webView.evaluateJavascript(script, null) }
    }

    private fun registerFinishedReceiver() {
        val filter = IntentFilter(AuraScreenCaptureService.ACTION_FINISHED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(finishedReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(finishedReceiver, filter)
        }
        receiverRegistered = true
    }

    override fun onResume() {
        super.onResume()
        if (AuraCaptureState.isRecording) notifyWeb("recording", null)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        webView.post { if (AuraCaptureState.isRecording) notifyWeb("recording", null) }
    }

    override fun onDestroy() {
        if (receiverRegistered) runCatching { unregisterReceiver(finishedReceiver) }
        // La capture continue dans le service même si la WebView est détruite.
        webView.destroy()
        super.onDestroy()
    }
}