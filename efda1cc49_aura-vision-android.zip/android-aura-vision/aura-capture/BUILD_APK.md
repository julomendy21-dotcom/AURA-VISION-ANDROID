# AURA VISION — Guide de compilation de l'APK Android

Ce guide décrit comment produire **réellement** l'APK de l'application Android
compagnon à partir du projet présent dans `android/aura-capture/`.

> **État honnête de ce dépôt** : l'APK **n'a pas** été compilé dans
> l'environnement Base44 (aucun JDK, aucun Android SDK, aucun Gradle n'y sont
> installés). Le projet est prêt à être compilé sur une machine ou via GitHub
> Actions ; le résultat n'est connu qu'après une compilation réelle.

---

## 1. Ce que le projet contient (vérifié)

```
android/aura-capture/
├── settings.gradle.kts                  dépôts google() / mavenCentral()
├── build.gradle.kts                     module Android : compileSdk 34, minSdk 26, targetSdk 34
├── gradle.properties                    AndroidX, JVM 2 Go, style Kotlin
├── gradlew                              script Gradle (Unix)
├── gradlew.bat                          script Gradle (Windows)
├── gradle/wrapper/
│   ├── gradle-wrapper.jar               présent (43 453 octets, GradleWrapperMain vérifié)
│   └── gradle-wrapper.properties        Gradle 8.7
├── .gitignore
├── AndroidManifest.xml                  permissions, activité, service mediaProjection
├── res/values/strings.xml               app_name + aura_app_url
├── res/values/themes.xml                thème sombre AURA VISION
├── res/xml/network_security_config.xml  HTTPS obligatoire, HTTP limité à 127.0.0.1
└── src/
    ├── AuraCaptureActivity.kt            WebView + autorisation Android + pont JS
    ├── AuraCaptureBridge.kt              window.AuraCapture
    ├── AuraScreenCaptureService.kt       service de premier plan, MP4 H.264
    ├── AuraCaptureState.kt               état partagé + dernier fichier + jeton
    ├── AuraMediaProbe.kt                 durée / résolution / cadence mesurées
    └── AuraCaptureServer.kt              pont local 127.0.0.1 servi sous jeton
```

Compatibilité : **JDK 17**, **Android SDK API 34** (Build-Tools 34.0.0),
**Gradle 8.7**, **AGP 8.5.2**, **Kotlin 1.9.24**.

---

## 2. Prérequis sur la machine

| Outil | Version | Où |
|---|---|---|
| JDK | **17** (obligatoire pour AGP 8.5) | [Temurin 17](https://adoptium.net/temurin/releases/?version=17) |
| Android SDK | **API 34** + Build-Tools 34.0.0 | Android Studio ▸ SDK Manager |
| Android Studio | Hedgehog 2023.1.1 ou plus récent (facultatif) | — |

Vérification rapide :

```bash
java -version        # doit afficher 17.x
echo $ANDROID_HOME   # doit pointer vers le SDK (ex. ~/Android/Sdk)
```

Si `ANDROID_HOME` est vide, créer `android/aura-capture/local.properties` :

```properties
sdk.dir=/chemin/vers/Android/Sdk
```

(`local.properties` est ignoré par Git : chemin propre à chaque machine.)

---

## 3. Méthode A — Android Studio (la plus simple)

1. **File ▸ Open** → sélectionner le dossier `android/aura-capture`.
2. Attendre la synchronisation Gradle (télécharge AGP, Kotlin et AndroidX).
3. **Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)**.
4. Cliquer sur **locate** dans la notification : l'APK est décompressé depuis
   `build/outputs/apk/debug/app-debug.apk`.

## 4. Méthode B — ligne de commande (wrapper inclus)

```bash
cd android/aura-capture

# Le wrapper est déjà présent (gradle-wrapper.jar + gradlew) :
./gradlew assembleDebug          # APK de test, signé avec la clé debug
# Windows : gradlew.bat assembleDebug
```

Résultat :

```
android/aura-capture/build/outputs/apk/debug/app-debug.apk
```

Ce projet est un **module racine** (le module Android est la racine Gradle, pas
un sous-dossier `app/`) : les sorties sont donc dans `build/outputs/…`.

Autres commandes utiles :

```bash
./gradlew assembleRelease        # non signé : voir § 6
./gradlew clean assembleDebug    # compilation propre
./gradlew --stop                 # arrête les démons Gradle
```

## 5. Méthode C — GitHub Actions (gratuit, sans machine Android)

Le workflow est fourni dans `android/aura-capture/ci/android-debug-apk.yml`.
Il doit être copié à cet emplacement exact pour que GitHub le prenne en compte
(l'éditeur Base44 n'a pas le droit d'écrire dans `.github/workflows/`) :

```bash
mkdir -p .github/workflows
cp android/aura-capture/ci/android-debug-apk.yml .github/workflows/
git add .github/workflows/android-debug-apk.yml
git commit -m "ci: compilation APK Android"
git push
```

Il compile alors automatiquement un **APK debug** à chaque modification du
dossier `android/aura-capture/`, ou manuellement.

1. Pousser le dépôt sur GitHub.
2. Onglet **Actions** ▸ **Android APK (debug)** ▸ **Run workflow**.
3. Quand le job est vert : **Artifacts** ▸ `aura-vision-debug-apk`
   (contient `app-debug.apk`, conservé 30 jours).

Détails du workflow : JDK 17 (Temurin), `android-actions/setup-android`
(API 34 + Build-Tools 34.0.0), cache Gradle, `./gradlew assembleDebug`,
publication de l'artefact. Aucune clé ni secret n'est nécessaire pour un APK
debug.

## 6. Signer une version de production (release)

Un APK release **non signé** ne s'installe pas. Créer une clé puis signer :

```bash
keytool -genkeypair -v -keystore aura-release.jks -alias aura \
        -keyalg RSA -keysize 2048 -validity 10000
```

Ajouter dans `build.gradle.kts` (bloc `android { … }`) :

```kotlin
signingConfigs {
    create("release") {
        storeFile = file(System.getenv("AURA_KEYSTORE") ?: "aura-release.jks")
        storePassword = System.getenv("AURA_STORE_PASSWORD")
        keyAlias = System.getenv("AURA_KEY_ALIAS")
        keyPassword = System.getenv("AURA_KEY_PASSWORD")
    }
}
buildTypes {
    release {
        isMinifyEnabled = false
        signingConfig = signingConfigs.getByName("release")
    }
}
```

Puis `./gradlew assembleRelease`. Ne **jamais** versionner le `.jks` ni les
mots de passe (`*.jks` et `*.keystore` figurent déjà dans `.gitignore`).

## 7. Installer l'APK

```bash
adb devices                  # le téléphone doit apparaître
adb install -r app-debug.apk
```

Sans câble : copier l'APK sur le téléphone, ouvrir le fichier et autoriser
« Installer des applications inconnues » pour l'application source.

Après installation, ouvrir **AURA VISION** : l'application affiche l'interface
web existante (`res/values/strings.xml` ▸ `aura_app_url`) et propose en plus la
capture d'écran native.

## 8. Dépannage — messages réels et solution

| Message | Cause | Solution |
|---|---|---|
| `SDK location not found` | SDK introuvable | définir `ANDROID_HOME` ou `local.properties` (§ 2) |
| `Unsupported class file major version 65` | Gradle lancé avec un JDK 21 | utiliser JDK 17 : `JAVA_HOME=/chemin/jdk-17 ./gradlew …` |
| `Failed to install the following Android SDK packages … licenses have not been accepted` | licences SDK | `$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses` |
| `Could not find gradle-wrapper.jar` | wrapper incomplet | `gradle wrapper --gradle-version 8.7` (ou récupérer le fichier du dépôt) |
| `compileSdk 34 requires JDK 17` | JDK 11 ou 8 | installer le JDK 17 et pointer `JAVA_HOME` |
| `Namespace not specified` | ne doit pas arriver : `namespace = "app.aura.capture"` est déjà présent | — |
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | APK d'une autre signature déjà installé | `adb uninstall app.aura.capture` puis réinstaller |
| La WebView affiche une page blanche | pas de réseau ou URL erronée | vérifier `aura_app_url` et la connexion |

## 9. Ce qui est vérifié, ce qui ne l'est pas

**Vérifié ici (inspection statique)** : présence et cohérence de tous les
fichiers Gradle/Kotlin/ressources, wrapper complet (jar + scripts, entrée
`GradleWrapperMain` confirmée), versions alignées (JDK 17 / AGP 8.5.2 /
Gradle 8.7 / compileSdk 34), permissions du manifeste, service
`foregroundServiceType="mediaProjection"`, pont local restreint à 127.0.0.1.

**Non vérifié** : compilation Kotlin/Gradle, exécution sur téléphone, capture
réelle. Ces étapes exigent un JDK, un Android SDK et un appareil.
