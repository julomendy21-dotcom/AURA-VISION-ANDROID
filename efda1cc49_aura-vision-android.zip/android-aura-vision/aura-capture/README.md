# AURA VISION — Application Android (capture d'écran native)

Application compagnon Android qui affiche l'interface AURA VISION existante
(WebView) et lui ajoute une capacité impossible dans un navigateur :
**enregistrer l'écran en continu pendant que l'utilisateur travaille dans une
autre application**, via `MediaProjection` + service de premier plan.

Aucun écran de l'application web n'est réécrit. Aucun module du moteur 1.1.0
n'est dupliqué ici : l'analyse reste dans AURA VISION (`BASE44_ENGINE`).

```
android/aura-capture/
├── settings.gradle.kts            configuration Gradle
├── build.gradle.kts               module Android (compileSdk 34, minSdk 26)
├── gradle.properties
├── gradlew / gradlew.bat          scripts du wrapper (inclus)
├── gradle/wrapper/
│   ├── gradle-wrapper.jar        présent — compilation sans `gradle` local
│   └── gradle-wrapper.properties Gradle 8.7
├── BUILD_APK.md                   guide de compilation complet
├── ci/android-debug-apk.yml       workflow GitHub Actions (à copier dans .github/workflows/)
├── AndroidManifest.xml            permissions + service + activité
├── res/values/strings.xml         dont aura_app_url (adresse de l'app web)
├── res/values/themes.xml
├── res/xml/network_security_config.xml
└── src/
    ├── AuraCaptureActivity.kt     WebView + autorisation Android + pont JS
    ├── AuraCaptureBridge.kt       window.AuraCapture exposé à la page
    ├── AuraScreenCaptureService.kt service de premier plan, MP4, galerie
    ├── AuraCaptureState.kt        état partagé + dernier fichier
    ├── AuraMediaProbe.kt          mesures réelles (durée, résolution, i/s)
    └── AuraCaptureServer.kt       pont local 127.0.0.1 + jeton (transfert du MP4)
```

## 1. Prérequis

| Outil | Version minimale |
|---|---|
| JDK | 17 |
| Android SDK | API 34 (Build-Tools 34.0.0) |
| Gradle | 8.7 (ou Android Studio Hedgehog+) |

## 2. Compilation

### Android Studio (recommandé)

1. `File ▸ Open` puis choisir le dossier `android/aura-capture`.
2. Laisser Gradle synchroniser (les dépendances sont déclarées dans `build.gradle.kts`).
3. `Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)`.

### Ligne de commande

```bash
cd android/aura-capture

export ANDROID_HOME=/chemin/vers/Android/Sdk   # ou local.properties

./gradlew assembleDebug     # APK de test (clé debug, installable directement)
./gradlew assembleRelease   # APK de production (non signé sans keystore)
```

Le wrapper est **inclus** (`gradlew`, `gradlew.bat`, `gradle-wrapper.jar`) :
aucun Gradle local n'est nécessaire, seul le JDK 17.

APK produit : `build/outputs/apk/debug/app-debug.apk` — la racine Gradle est
le module Android lui-même, il n'y a pas de sous-dossier `app/`.

Guide détaillé (prérequis, signature, dépannage, GitHub Actions) :
**[`BUILD_APK.md`](BUILD_APK.md)**.

Installation sur le téléphone :

```bash
adb install -r app-debug.apk
```

## 3. Permissions demandées

| Permission | Pourquoi |
|---|---|
| `INTERNET` | charge l'interface AURA VISION |
| `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MEDIA_PROJECTION` | service de capture conforme Android 14 |
| `POST_NOTIFICATIONS` | notification permanente avec bouton Arrêter (Android 13+) |
| `CAMERA` | sources caméra frontale/arrière de la page Capture |
| Autorisation `MediaProjection` | **demandée à chaque session**, jamais mémorisée |

Aucune permission de stockage n'est demandée : le MP4 est écrit dans
`Movies/AuraVision` via MediaStore (dossier applicatif, pas d'accès global).

## 4. Contrat du pont (`window.AuraCapture`)

| Méthode | Rôle |
|---|---|
| `isNativeCaptureAvailable()` | `true` dans l'application Android |
| `startCapture()` | ouvre la boîte de dialogue Android |
| `stopCapture()` | arrête et finalise le MP4 |
| `isRecording()` | état réel du service |
| `latestCaptureUrl()` | URL `http://127.0.0.1:<port>/<jeton>/latest.mp4` ou `""` |
| `latestCaptureInfo()` | JSON : durée, largeur, hauteur, `fps` mesurées, taille |
| `requestPermissions()` | notifications Android 13+ |

La page reçoit aussi les événements
`window.addEventListener("aura-capture", …)` avec
`detail.state ∈ { recording, stopped, denied, error }`.

Côté web, tout est isolé dans `src/lib/native-capture.js` et utilisé par
`src/components/capture/SourceRecorder.jsx`. Sur un navigateur classique, le
pont est absent et la page utilise `getDisplayMedia` comme avant.

## 5. Cadence et qualité

- Cible **60 i/s**, repli **30 i/s** si l'encodeur du téléphone refuse
  (`buildRecorder` essaie 60 puis 30).
- La cadence **réellement obtenue** est mesurée après l'arrêt
  (`MediaMetadataRetriever`, images ÷ durée) et affichée sur la page.
- Conteneur **MP4 / H.264**, horodatages fournis par MediaRecorder.
- Intégrité vérifiée avant tout transfert (`readable`, taille > 0,
  durée > 0, résolution > 0).

## 6. Ce qui est vérifié et ce qui ne l'est pas

**Vérifié dans l'environnement Base44** : présence et cohérence de tous les
fichiers Gradle/Kotlin/ressources, wrapper complet (`gradle-wrapper.jar` +
`gradlew` + `gradlew.bat`, entrée `GradleWrapperMain` confirmée, Gradle 8.7),
alignement des versions (JDK 17 / AGP 8.5.2 / Kotlin 1.9.24 / compileSdk 34),
permissions du manifeste, service `mediaProjection`. **Aucun APK n'a été
produit ici** : l'environnement Base44 ne contient ni JDK, ni SDK Android.

**Non exécuté** : compilation Kotlin/Gradle, installation, capture réelle,
notification, transfert local, analyse — impossible sans JDK, sans SDK Android
et sans téléphone connecté. Voir `BUILD_APK.md` § 9.

## 7. Plan de test — TECNO KI7, Android 13

1. Installer l'APK (`adb install -r app-debug.apk`), ouvrir **AURA VISION**.
2. Se connecter, aller sur **Capture d'écran**, choisir **Capture d'écran**.
3. Appuyer sur **Démarrer la capture Android** → la boîte Android
   « Démarrer l'enregistrement ou la diffusion ? » doit apparaître.
4. Accepter : la notification « AURA VISION enregistre l'écran » doit rester
   visible avec le bouton **Arrêter**.
5. Ouvrir une autre application (Galerie, Chrome), l'utiliser 10–20 s.
   → l'enregistrement doit continuer (vérifier le chronomètre de la notification).
6. Revenir sur AURA VISION → l'indicateur REC doit toujours être actif.
7. Appuyer sur **Arrêter** (page ou notification).
8. Vérifier : la vidéo apparaît seule (contrôles, durée, résolution, i/s
   mesurées) et un MP4 est présent dans `Movies/AuraVision`.
9. **Analyser dans AURA VISION** → choisir `ONE_BALL` ou `TWO_BALLS` →
   lancer `BASE44_ENGINE` → vérifier le rapport.
10. Cas négatifs : refuser l'autorisation Android ; ouvrir une application
    protégée par `FLAG_SECURE` (écran noir attendu, aucune erreur).

## 8. Limites assumées

- Les applications protégées par `FLAG_SECURE` (banque, certains lecteurs
  DRM) apparaissent noires : Android l'impose, l'application ne contourne rien.
- Aucune capture possible sans validation de l'utilisateur à chaque session.
- Le transfert vers la page passe par la mémoire du WebView : au-delà de
  ~200 Mo, préférer l'import du fichier depuis la galerie.
- iOS ne permet pas ce type de capture hors extension ReplayKit : non couvert.
